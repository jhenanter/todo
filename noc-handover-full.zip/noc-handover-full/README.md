# NOC Shift Handover Automation

A Vercel + Next.js project for NOC shift handover reporting.

## Features

### Option A - Manual Report Generator
- Manual incident input
- Alarm and escalation tracking
- Copy generated report

### Option B - Automated Report
- API-based report generation
- Ready for monitoring tool integration
- Future-ready for Zabbix, PRTG, ServiceNow, Meraki, Cisco

## Installation

```bash
npm install
npm run dev
```

## Deployment

1. Push to GitHub
2. Connect repository to Vercel
3. Deploy

## Future Integrations
- Zabbix
- PRTG
- ServiceNow
- Teams notifications
- Scheduled reports
