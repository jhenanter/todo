export async function GET() {

  const incidents = [
    "AP17 Down – Ongoing",
    "WAN Latency – Investigating"
  ];

  const alarms = [
    "Core Switch CPU High",
    "Firewall HA Warning"
  ];

  const escalations = [
    "ISP Ticket Pending"
  ];

  const health = "95% devices healthy, 3 under observation";

  const report = `
NOC SHIFT HANDOVER REPORT
Date: ${new Date().toLocaleDateString()}

Open Incidents:
${incidents.join('\n')}

Critical Alarms:
${alarms.join('\n')}

Pending Escalations:
${escalations.join('\n')}

Daily Health Summary:
${health}

Prepared by: NOC Operations
`;

  return Response.json({ report });
}
