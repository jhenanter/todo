'use client';
import { useState } from 'react';

export default function Home() {
  const [incidents, setIncidents] = useState('');
  const [alarms, setAlarms] = useState('');
  const [escalations, setEscalations] = useState('');
  const [health, setHealth] = useState('');
  const [manualReport, setManualReport] = useState('');
  const [autoReport, setAutoReport] = useState('');

  const generateManual = () => {
    const report = `
NOC SHIFT HANDOVER REPORT
Date: ${new Date().toLocaleDateString()}
Time: ${new Date().toLocaleTimeString()}

Open Incidents:
${incidents}

Critical Alarms:
${alarms}

Pending Escalations:
${escalations}

Daily Health Summary:
${health}

Prepared by: NOC Operations
`;
    setManualReport(report);
  };

  const loadAuto = async () => {
    const res = await fetch('/api/handover');
    const data = await res.json();
    setAutoReport(data.report);
  };

  const copyText = (text) => {
    navigator.clipboard.writeText(text);
    alert('Copied!');
  };

  return (
    <main style={{padding:30,fontFamily:'Arial'}}>
      <h1>NOC Shift Handover Automation</h1>

      <h2>Option A - Manual Generator</h2>

      <textarea placeholder="Open Incidents" rows={3} style={{width:'100%',marginBottom:10}}
        onChange={(e)=>setIncidents(e.target.value)} />

      <textarea placeholder="Critical Alarms" rows={3} style={{width:'100%',marginBottom:10}}
        onChange={(e)=>setAlarms(e.target.value)} />

      <textarea placeholder="Pending Escalations" rows={3} style={{width:'100%',marginBottom:10}}
        onChange={(e)=>setEscalations(e.target.value)} />

      <textarea placeholder="Daily Health Summary" rows={3} style={{width:'100%',marginBottom:10}}
        onChange={(e)=>setHealth(e.target.value)} />

      <button onClick={generateManual}>Generate Manual Report</button>
      <button style={{marginLeft:10}} onClick={()=>copyText(manualReport)}>Copy</button>

      <pre style={{background:'#eee',padding:15,marginTop:10}}>
        {manualReport}
      </pre>

      <hr style={{margin:'30px 0'}} />

      <h2>Option B - Automated Generator</h2>

      <button onClick={loadAuto}>Generate Automated Report</button>
      <button style={{marginLeft:10}} onClick={()=>copyText(autoReport)}>Copy</button>

      <pre style={{background:'#eee',padding:15,marginTop:10}}>
        {autoReport}
      </pre>
    </main>
  );
}
